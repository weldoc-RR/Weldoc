import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { determinerCriteres, evaluerConformite, type Mesure } from "@/lib/tolerances";

const MesureSchema = z.object({
  position: z.string(),
  diametreMm: z.number().optional(),
  epaisseurMm: z.number().optional(),
});

const CreateControleSchema = z.object({
  jointId: z.string().min(1),
  controleurId: z.string().min(1),
  outilId: z.string().optional(),
  normeProduit: z.string().min(1), // pour interroger le moteur de tolérances
  diametreNominalMm: z.number(),
  epaisseurNominaleMm: z.number(),
  mesures: z.array(MesureSchema).min(1),
});

// POST /api/controles-dimensionnels
// 1) détermine les critères applicables (traçables vers une norme/version)
// 2) évalue la conformité des mesures saisies par le contrôleur
// 3) si hors tolérance, ouvre automatiquement une FNC liée au joint et au contrôle
export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = CreateControleSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const { jointId, controleurId, outilId, normeProduit, diametreNominalMm, epaisseurNominaleMm, mesures } =
    parsed.data;

  let criteres;
  try {
    criteres = determinerCriteres({ normeProduit, diametreNominalMm, epaisseurNominaleMm });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 422 });
  }

  const resultat = evaluerConformite(mesures as Mesure[], criteres);

  const controle = await prisma.controleDimensionnel.create({
    data: {
      jointId,
      controleurId,
      outilId,
      mesures: mesures as object,
      criteresAppliques: criteres as unknown as object,
      resultat,
    },
  });

  let fnc = null;
  if (resultat === "HORS_TOLERANCE") {
    const joint = await prisma.joint.findUniqueOrThrow({ where: { id: jointId } });
    const reference = `FNC-${joint.numero}-${Date.now()}`;

    fnc = await prisma.fNC.create({
      data: {
        reference,
        affaireId: joint.affaireId,
        jointId,
        controleOrigineId: controle.id,
        description: `Contrôle dimensionnel hors tolérance sur ${joint.numero} (critères: ${criteres.norme}).`,
        impact: "BLOQUANTE",
        statut: "DETECTION",
      },
    });
  }

  return NextResponse.json({ controle, criteres, fncCreee: fnc }, { status: 201 });
}
